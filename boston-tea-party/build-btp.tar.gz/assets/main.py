"""
Boston Tea Party — Arcade RPG
10 levels, boss fight, arcade high-score board.
"""

import pygame
import random
import math
import sys
import json
import os
import asyncio

# ---------------------------------------------------------------------------
# Constants
# ---------------------------------------------------------------------------
SCREEN_W, SCREEN_H = 1024, 768
FPS = 60
SCORE_FILE = os.path.join(os.path.dirname(os.path.abspath(__file__)), "highscores.json")

# Colors
WHITE        = (255, 255, 255)
BLACK        = (0, 0, 0)
WOOD_DARK    = (101, 67, 33)
WOOD_LIGHT   = (139, 90, 43)
WOOD_PLANK   = (160, 110, 60)
HULL_DARK    = (70, 45, 20)
HULL_MID     = (90, 58, 28)
HULL_BAND    = (180, 140, 60)
WATER        = (30, 100, 180)
WATER_LIGHT  = (60, 140, 210)
WATER_DARK   = (10, 40, 100)
SKY_TOP      = (10, 10, 40)
SKY_BOT      = (25, 25, 70)
MOON_COLOR   = (240, 240, 200)
TEA_SMALL    = (34, 139, 34)
TEA_MED      = (184, 134, 11)
TEA_LARGE    = (178, 34, 34)
SKIN         = (235, 200, 160)
COAT_BLUE    = (40, 60, 150)
PANTS_TAN    = (190, 170, 130)
HAIR_GRAY    = (180, 180, 180)
STAMINA_BG   = (60, 60, 60)
STAMINA_FG   = (50, 205, 50)
STAMINA_LOW  = (220, 50, 50)
HEALTH_FG    = (220, 40, 40)
SPLASH_CLR   = (100, 180, 255)
ROPE_COLOR   = (180, 160, 100)
RAIL_COLOR   = (120, 80, 40)
SAIL_COLOR   = (230, 220, 190)
SAIL_SHADOW  = (200, 190, 165)
FLAG_RED     = (180, 30, 30)
REDCOAT_COAT = (180, 30, 30)
REDCOAT_PANTS = (240, 240, 230)
MUZZLE_FLASH = (255, 255, 150)
SMOKE_COLOR  = (200, 200, 200)
GOLD         = (255, 215, 0)
ARCADE_BG    = (10, 5, 30)
ARCADE_BORDER = (80, 60, 180)

# Ship geometry
WATERLINE_Y  = 540
DECK_Y       = 430
UPPER_DECK_Y = 370
DECK_LEFT    = 120
DECK_RIGHT   = 880
UPPER_LEFT   = 120
UPPER_RIGHT  = 320
BOW_TIP_X    = 940
STERN_X      = 80
DECK_CX      = (DECK_LEFT + DECK_RIGHT) // 2

THROW_MARGIN = 60

# Player
PLAYER_SPEED           = 4.0
PLAYER_CARRY_SPEED_MUL = 0.5
STAMINA_MAX            = 100.0
STAMINA_REGEN          = 14.0
STAMINA_WALK_DRAIN     = 3.0
THROW_STAMINA_MULT     = 1.0
HEALTH_MAX             = 100.0

# Musket
MUSKET_RELOAD_TIME = 2.0
BULLET_SPEED       = 700.0

# Tea
CHEST_TYPES = [
    ("Small",  22, 18, TEA_SMALL, 8,  100),
    ("Medium", 30, 24, TEA_MED,   18, 300),
    ("Large",  40, 32, TEA_LARGE, 35, 600),
]
MAX_CHESTS = 6

# Redcoats
REDCOAT_SPEED          = 1.5
REDCOAT_ATTACK_DMG     = 8.0
REDCOAT_SHOOT_INTERVAL = 3.5
ENEMY_BULLET_SPEED     = 300.0
ENEMY_BULLET_DMG       = 15.0

# Heart
HEART_HEAL_AMOUNT = 30.0
HEART_FLOAT_SPEED = 40.0

# Boss
BOSS_HP            = 50       # number of hits
BOSS_SPEED         = 2.5
BOSS_SLASH_DMG     = 25.0
BOSS_SLASH_RANGE   = 60
BOSS_SLASH_COOLDOWN = 2.0
BOSS_HIT_HEAL      = 5.0     # health gained per shot on boss

# Particles
SPLASH_PARTICLES = 14
PARTICLE_LIFE    = 0.7

# Level config: (level, redcoat_spawn_interval, redcoat_speed_mult, chest_spawn_interval, max_redcoats)
LEVEL_CONFIG = {
    1:  (5.0, 1.0, 3.5, 4),
    2:  (4.5, 1.1, 3.2, 5),
    3:  (4.0, 1.2, 3.0, 5),
    4:  (3.5, 1.3, 2.8, 6),
    5:  (3.0, 1.4, 2.5, 6),
    6:  (2.5, 1.5, 2.3, 7),
    7:  (2.0, 1.6, 2.0, 7),
    8:  (1.8, 1.7, 1.8, 8),
    9:  (1.5, 1.9, 1.5, 9),
    10: (999, 1.0, 2.0, 0),  # boss level, no regular redcoats
}
LEVEL_DURATION = 60.0  # seconds per level (1-9)

# ---------------------------------------------------------------------------
# High Score system
# ---------------------------------------------------------------------------

def load_scores():
    if os.path.exists(SCORE_FILE):
        try:
            with open(SCORE_FILE, "r") as f:
                return json.load(f)
        except Exception:
            return []
    return []


def save_scores(scores):
    try:
        with open(SCORE_FILE, "w") as f:
            json.dump(scores, f, indent=2)
    except Exception:
        pass


def add_score(name, pin, score, level):
    scores = load_scores()
    scores.append({"name": name, "pin": pin, "score": score, "level": level})
    scores.sort(key=lambda s: s["score"], reverse=True)
    scores = scores[:20]  # keep top 20
    save_scores(scores)
    return scores

# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def clamp(v, lo, hi):
    return max(lo, min(hi, v))


def draw_gradient_rect(surf, rect, top_color, bot_color):
    x, y, w, h = rect
    for row in range(h):
        t = row / max(h - 1, 1)
        r = int(top_color[0] + (bot_color[0] - top_color[0]) * t)
        g = int(top_color[1] + (bot_color[1] - top_color[1]) * t)
        b = int(top_color[2] + (bot_color[2] - top_color[2]) * t)
        pygame.draw.line(surf, (r, g, b), (x, y + row), (x + w, y + row))

# ---------------------------------------------------------------------------
# Particle
# ---------------------------------------------------------------------------

class Particle:
    def __init__(self, x, y, color=SPLASH_CLR, gravity=300, life=PARTICLE_LIFE):
        angle = random.uniform(-math.pi * 0.9, -math.pi * 0.1)
        speed = random.uniform(60, 200)
        self.x, self.y = x, y
        self.vx = math.cos(angle) * speed
        self.vy = math.sin(angle) * speed
        self.life = life
        self.max_life = life
        self.radius = random.randint(2, 5)
        self.color = color
        self.gravity = gravity

    def update(self, dt):
        self.vy += self.gravity * dt
        self.x += self.vx * dt
        self.y += self.vy * dt
        self.life -= dt

    def draw(self, surf):
        alpha = clamp(self.life / self.max_life, 0, 1)
        r = max(1, int(self.radius * alpha))
        c = self.color
        faded = (int(c[0] * alpha), int(c[1] * alpha), int(c[2] * alpha))
        pygame.draw.circle(surf, faded, (int(self.x), int(self.y)), r)

# ---------------------------------------------------------------------------
# Floating text
# ---------------------------------------------------------------------------

class FloatingText:
    def __init__(self, x, y, text, color=WHITE):
        self.x, self.y = x, y
        self.text = text
        self.color = color
        self.life = 1.2

    def update(self, dt):
        self.y -= 40 * dt
        self.life -= dt

    def draw(self, surf, font):
        if self.life <= 0:
            return
        alpha = clamp(self.life / 1.2, 0, 1)
        ts = font.render(self.text, True, self.color)
        ts.set_alpha(int(255 * alpha))
        surf.blit(ts, (self.x - ts.get_width() // 2, int(self.y)))

# ---------------------------------------------------------------------------
# Tea chest
# ---------------------------------------------------------------------------

class TeaChest:
    def __init__(self, x, y, ctype):
        self.name, self.w, self.h, self.color, self.weight, self.points = ctype
        self.x, self.y = x, y
        self.carried = False

    def rect(self):
        return pygame.Rect(self.x - self.w // 2, self.y - self.h, self.w, self.h)

    def draw(self, surf, font_sm):
        r = self.rect()
        pygame.draw.rect(surf, BLACK, r.move(2, 2))
        pygame.draw.rect(surf, self.color, r)
        stripe = pygame.Rect(r.x + 2, r.y + 2, r.w - 4, 4)
        lighter = tuple(min(255, c + 60) for c in self.color)
        pygame.draw.rect(surf, lighter, stripe)
        pygame.draw.rect(surf, BLACK, r, 2)
        pygame.draw.line(surf, WOOD_DARK, (r.x, r.y), (r.right, r.bottom), 1)
        pygame.draw.line(surf, WOOD_DARK, (r.right, r.y), (r.x, r.bottom), 1)
        label = font_sm.render(self.name, True, WHITE)
        surf.blit(label, (r.centerx - label.get_width() // 2, r.y - 14))

# ---------------------------------------------------------------------------
# Bullets
# ---------------------------------------------------------------------------

class Bullet:
    def __init__(self, x, y, direction):
        self.x, self.y = x, y
        self.vx = BULLET_SPEED * direction
        self.alive = True

    def update(self, dt):
        self.x += self.vx * dt
        if self.x < 0 or self.x > SCREEN_W:
            self.alive = False

    def draw(self, surf):
        pygame.draw.circle(surf, (220, 200, 60), (int(self.x), int(self.y)), 3)
        trail_x = self.x - (self.vx * 0.02)
        pygame.draw.line(surf, (200, 180, 40), (int(trail_x), int(self.y)), (int(self.x), int(self.y)), 2)


class EnemyBullet:
    def __init__(self, x, y, direction):
        self.x, self.y = x, y
        self.vx = ENEMY_BULLET_SPEED * direction
        self.alive = True

    def update(self, dt):
        self.x += self.vx * dt
        if self.x < 0 or self.x > SCREEN_W:
            self.alive = False

    def hit_player(self, player):
        return abs(self.x - player.x) < 16 and abs(self.y - player.y + 25) < 30

    def draw(self, surf):
        pygame.draw.circle(surf, (200, 60, 60), (int(self.x), int(self.y)), 3)
        trail_x = self.x - (self.vx * 0.015)
        pygame.draw.line(surf, (180, 40, 40), (int(trail_x), int(self.y)), (int(self.x), int(self.y)), 2)

# ---------------------------------------------------------------------------
# Heart pickup
# ---------------------------------------------------------------------------

class HeartPickup:
    def __init__(self, x, y):
        self.x, self.y = x, y
        self.target_y = DECK_Y - 16
        self.alive = True
        self.bob_timer = 0.0
        self.landed = False
        self.lifetime = 8.0

    def update(self, dt):
        if not self.landed:
            self.y += HEART_FLOAT_SPEED * dt
            if self.y >= self.target_y:
                self.y = self.target_y
                self.landed = True
        else:
            self.lifetime -= dt
            if self.lifetime <= 0:
                self.alive = False
        self.bob_timer += dt

    def hit_player(self, player):
        return abs(self.x - player.x) < 28 and abs(self.y - (player.y - 20)) < 30

    def draw(self, surf):
        x, y = int(self.x), int(self.y)
        bob = int(math.sin(self.bob_timer * 4) * 3)
        y += bob
        if self.landed and self.lifetime < 2.0 and int(self.lifetime * 6) % 2 == 0:
            return
        pygame.draw.circle(surf, (220, 30, 60), (x - 5, y - 4), 6)
        pygame.draw.circle(surf, (220, 30, 60), (x + 5, y - 4), 6)
        pygame.draw.polygon(surf, (220, 30, 60), [(x - 10, y - 2), (x + 10, y - 2), (x, y + 10)])
        pygame.draw.circle(surf, (255, 120, 140), (x - 4, y - 6), 2)

# ---------------------------------------------------------------------------
# Redcoat enemy
# ---------------------------------------------------------------------------

class Redcoat:
    def __init__(self, x, climb_from_y, speed_mult=1.0):
        self.x, self.y = x, climb_from_y
        self.target_y = DECK_Y
        self.on_deck = False
        self.alive = True
        self.facing = 0
        self.walk_frame = 0.0
        self.climb_speed = 60
        self.speed_mult = speed_mult
        self.shoot_timer = random.uniform(1.5, REDCOAT_SHOOT_INTERVAL)
        self.shoot_flash = 0.0
        self.dying = False
        self.death_timer = 0.6
        self.death_vy = -150
        self.death_vx = 0

    def update(self, dt, player_x):
        if self.dying:
            self.death_timer -= dt
            self.death_vy += 400 * dt
            self.y += self.death_vy * dt
            self.x += self.death_vx * dt
            if self.death_timer <= 0:
                self.alive = False
            return
        if self.shoot_flash > 0:
            self.shoot_flash -= dt
        if not self.on_deck:
            self.y -= self.climb_speed * dt
            if self.y <= self.target_y:
                self.y = self.target_y
                self.on_deck = True
        else:
            if abs(self.x - player_x) > 20:
                d = 1 if player_x > self.x else -1
                self.facing = d
                self.x += REDCOAT_SPEED * self.speed_mult * d
                self.walk_frame += dt * 6
            else:
                self.walk_frame = 0
            self.x = clamp(self.x, DECK_LEFT + 10, DECK_RIGHT - 10)
            self.shoot_timer -= dt

    def try_shoot(self, player_x):
        if not self.on_deck or self.dying or self.shoot_timer > 0:
            return None
        self.shoot_timer = random.uniform(REDCOAT_SHOOT_INTERVAL * 0.7, REDCOAT_SHOOT_INTERVAL * 1.3)
        self.shoot_flash = 0.12
        d = 1 if player_x > self.x else -1
        self.facing = d
        return EnemyBullet(self.x + d * 20, self.y - 28, d)

    def hit_rect(self):
        return pygame.Rect(self.x - 12, self.y - 48, 24, 48)

    def die(self, bullet_dir):
        self.dying = True
        self.death_vx = bullet_dir * 80

    def draw(self, surf):
        x, y = int(self.x), int(self.y)
        f = self.facing if self.facing != 0 else 1
        bob = int(math.sin(self.walk_frame) * 2) if self.on_deck else 0
        if not self.on_deck and not self.dying:
            pygame.draw.rect(surf, REDCOAT_COAT, (x - 8, int(self.y) - 30, 16, 24))
            pygame.draw.circle(surf, SKIN, (x, int(self.y) - 36), 7)
            pygame.draw.rect(surf, BLACK, (x - 6, int(self.y) - 48, 12, 12))
            return
        pygame.draw.rect(surf, REDCOAT_PANTS, (x - 7, y - 18 + bob, 6, 16))
        pygame.draw.rect(surf, REDCOAT_PANTS, (x + 1, y - 18 + bob, 6, 16))
        pygame.draw.rect(surf, BLACK, (x - 8, y - 4 + bob, 7, 4))
        pygame.draw.rect(surf, BLACK, (x + 1, y - 4 + bob, 7, 4))
        pygame.draw.rect(surf, REDCOAT_COAT, (x - 9, y - 34 + bob, 18, 18))
        pygame.draw.line(surf, WHITE, (x - 8, y - 34 + bob), (x + 8, y - 18 + bob), 2)
        pygame.draw.line(surf, WHITE, (x + 8, y - 34 + bob), (x - 8, y - 18 + bob), 2)
        arm_y = y - 30 + bob
        pygame.draw.rect(surf, REDCOAT_COAT, (x - 13, arm_y, 5, 12))
        pygame.draw.rect(surf, REDCOAT_COAT, (x + 8, arm_y, 5, 12))
        pygame.draw.circle(surf, SKIN, (x - 11, arm_y + 13), 3)
        pygame.draw.circle(surf, SKIN, (x + 10, arm_y + 13), 3)
        pygame.draw.line(surf, (80, 60, 40), (x + f * 10, arm_y + 6), (x + f * 26, arm_y - 4), 2)
        if self.shoot_flash > 0:
            pygame.draw.circle(surf, MUZZLE_FLASH, (x + f * 28, arm_y - 2), 6)
            pygame.draw.circle(surf, WHITE, (x + f * 28, arm_y - 2), 3)
        head_y = y - 42 + bob
        pygame.draw.circle(surf, SKIN, (x, head_y), 7)
        ex = x + f * 2
        pygame.draw.circle(surf, BLACK, (ex - 2, head_y), 1)
        pygame.draw.circle(surf, BLACK, (ex + 2, head_y), 1)
        pygame.draw.rect(surf, BLACK, (x - 6, head_y - 18, 12, 14))
        pygame.draw.rect(surf, BLACK, (x - 8, head_y - 6, 16, 3))
        pygame.draw.rect(surf, (200, 170, 40), (x - 3, head_y - 14, 6, 6))

# ---------------------------------------------------------------------------
# Boss — Giant Redcoat General
# ---------------------------------------------------------------------------

class Boss:
    def __init__(self):
        self.x = DECK_RIGHT - 100
        self.y = DECK_Y
        self.hp = BOSS_HP
        self.max_hp = BOSS_HP
        self.alive = True
        self.facing = -1
        self.walk_frame = 0.0
        self.slash_timer = BOSS_SLASH_COOLDOWN
        self.slashing = False
        self.slash_anim = 0.0
        self.hit_flash = 0.0
        self.dying = False
        self.death_timer = 2.0
        self.scale = 2.5  # giant

    def update(self, dt, player_x):
        if self.dying:
            self.death_timer -= dt
            if self.death_timer <= 0:
                self.alive = False
            return

        if self.hit_flash > 0:
            self.hit_flash -= dt

        # Walk toward player
        if abs(self.x - player_x) > BOSS_SLASH_RANGE - 10:
            d = 1 if player_x > self.x else -1
            self.facing = d
            self.x += BOSS_SPEED * d
            self.walk_frame += dt * 4
        else:
            self.facing = 1 if player_x > self.x else -1
            self.walk_frame = 0

        self.x = clamp(self.x, DECK_LEFT + 30, DECK_RIGHT - 30)

        # Slash attack
        if self.slashing:
            self.slash_anim -= dt
            if self.slash_anim <= 0:
                self.slashing = False
        else:
            self.slash_timer -= dt
            if self.slash_timer <= 0 and abs(self.x - player_x) < BOSS_SLASH_RANGE:
                self.slashing = True
                self.slash_anim = 0.4
                self.slash_timer = BOSS_SLASH_COOLDOWN

    def is_slash_hitting(self, player_x):
        """Returns True during the active slash frame if player is in range."""
        if self.slashing and self.slash_anim > 0.15 and self.slash_anim < 0.35:
            return abs(self.x - player_x) < BOSS_SLASH_RANGE
        return False

    def take_hit(self):
        self.hp -= 1
        self.hit_flash = 0.15
        if self.hp <= 0:
            self.dying = True

    def hit_rect(self):
        s = self.scale
        return pygame.Rect(self.x - int(15 * s), self.y - int(55 * s), int(30 * s), int(55 * s))

    def draw(self, surf):
        x, y = int(self.x), int(self.y)
        f = self.facing
        s = self.scale
        bob = int(math.sin(self.walk_frame) * 3)

        # Dying fade
        if self.dying:
            alpha = clamp(self.death_timer / 2.0, 0, 1)
            if int(self.death_timer * 10) % 2 == 0:
                return  # flash/blink

        # Hit flash
        flash = self.hit_flash > 0

        coat_c = (255, 100, 100) if flash else (160, 20, 20)
        pants_c = (255, 240, 240) if flash else REDCOAT_PANTS
        skin_c = (255, 230, 200) if flash else SKIN

        si = lambda v: int(v * s)

        # Legs
        pygame.draw.rect(surf, pants_c, (x - si(8), y - si(20) + bob, si(7), si(18)))
        pygame.draw.rect(surf, pants_c, (x + si(1), y - si(20) + bob, si(7), si(18)))
        # Boots
        pygame.draw.rect(surf, BLACK, (x - si(9), y - si(4) + bob, si(9), si(5)))
        pygame.draw.rect(surf, BLACK, (x + si(1), y - si(4) + bob, si(9), si(5)))

        # Body
        pygame.draw.rect(surf, coat_c, (x - si(11), y - si(40) + bob, si(22), si(22)))
        # Epaulettes (gold shoulder pads — he's a general)
        pygame.draw.circle(surf, GOLD, (x - si(12), y - si(38) + bob), si(4))
        pygame.draw.circle(surf, GOLD, (x + si(12), y - si(38) + bob), si(4))
        # Medals
        pygame.draw.circle(surf, GOLD, (x - si(3), y - si(34) + bob), si(2))
        pygame.draw.circle(surf, GOLD, (x + si(3), y - si(34) + bob), si(2))
        pygame.draw.circle(surf, WHITE, (x, y - si(30) + bob), si(2))

        # Sash
        pygame.draw.line(surf, (200, 180, 40), (x - si(10), y - si(40) + bob),
                         (x + si(10), y - si(20) + bob), si(2))

        # Arms
        arm_y_pos = y - si(36) + bob
        if self.slashing:
            # Sword slash animation
            progress = 1.0 - (self.slash_anim / 0.4)
            angle = -60 + progress * 160
            rad = math.radians(angle)
            sword_len = si(35)
            sx = x + f * si(12)
            sy = arm_y_pos + si(6)
            ex = sx + int(math.cos(rad) * sword_len * f)
            ey = sy + int(math.sin(rad) * sword_len)
            # Arm
            pygame.draw.line(surf, coat_c, (sx, sy), (ex - f * si(5), ey), si(3))
            # Sword
            pygame.draw.line(surf, (180, 180, 200), (sx, sy), (ex, ey), si(2))
            pygame.draw.line(surf, WHITE, (ex - f * 2, ey - 2), (ex + f * 2, ey + 2), si(1))
            # Slash arc effect
            if 0.15 < self.slash_anim < 0.35:
                arc_r = si(30)
                for i in range(3):
                    a = math.radians(-30 + progress * 140 + i * 15)
                    px = sx + int(math.cos(a) * arc_r * f)
                    py = sy + int(math.sin(a) * arc_r)
                    pygame.draw.circle(surf, (255, 255, 200), (px, py), 2)
        else:
            # Normal arms + sword at side
            pygame.draw.rect(surf, coat_c, (x - si(15), arm_y_pos, si(5), si(14)))
            pygame.draw.rect(surf, coat_c, (x + si(10), arm_y_pos, si(5), si(14)))
            # Sword at side
            pygame.draw.line(surf, (180, 180, 200), (x + f * si(12), arm_y_pos + si(10)),
                             (x + f * si(12), arm_y_pos + si(28)), si(1))
            # Guard
            pygame.draw.line(surf, GOLD, (x + f * si(10), arm_y_pos + si(10)),
                             (x + f * si(14), arm_y_pos + si(10)), si(1))

        # Head (bigger)
        head_y = y - si(48) + bob
        pygame.draw.circle(surf, skin_c, (x, head_y), si(9))
        # Angry eyes
        ex = x + f * si(3)
        pygame.draw.circle(surf, BLACK, (ex - si(3), head_y), si(2))
        pygame.draw.circle(surf, BLACK, (ex + si(3), head_y), si(2))
        # Angry eyebrows
        pygame.draw.line(surf, BLACK, (ex - si(5), head_y - si(4)),
                         (ex - si(1), head_y - si(2)), 2)
        pygame.draw.line(surf, BLACK, (ex + si(1), head_y - si(2)),
                         (ex + si(5), head_y - si(4)), 2)
        # Mouth — snarl
        pygame.draw.line(surf, BLACK, (x - si(3), head_y + si(4)),
                         (x + si(3), head_y + si(4)), 2)

        # Bicorn hat (general's hat — wider than shako)
        hat_y = head_y - si(10)
        pygame.draw.polygon(surf, (20, 20, 20), [
            (x - si(16), hat_y + si(4)),
            (x + si(16), hat_y + si(4)),
            (x + si(10), hat_y - si(6)),
            (x, hat_y - si(8)),
            (x - si(10), hat_y - si(6)),
        ])
        pygame.draw.rect(surf, (20, 20, 20), (x - si(12), hat_y + si(2), si(24), si(4)))
        # Gold trim on hat
        pygame.draw.line(surf, GOLD, (x - si(14), hat_y + si(4)),
                         (x + si(14), hat_y + si(4)), 2)
        # Feather plume
        pygame.draw.ellipse(surf, (220, 220, 220), (x + f * si(8), hat_y - si(14), si(6), si(12)))

        # Boss HP bar above head
        if not self.dying:
            bar_w = si(40)
            bar_h = 8
            bar_x = x - bar_w // 2
            bar_y = hat_y - si(16)
            pygame.draw.rect(surf, (40, 40, 40), (bar_x, bar_y, bar_w, bar_h))
            fill = self.hp / self.max_hp
            pygame.draw.rect(surf, (200, 30, 30), (bar_x, bar_y, int(bar_w * fill), bar_h))
            pygame.draw.rect(surf, WHITE, (bar_x, bar_y, bar_w, bar_h), 1)

# ---------------------------------------------------------------------------
# Player
# ---------------------------------------------------------------------------

class Player:
    def __init__(self, x):
        self.x = x
        self.y = DECK_Y
        self.stamina = STAMINA_MAX
        self.health = HEALTH_MAX
        self.carrying = None
        self.score = 0
        self.facing = 1
        self.walk_frame = 0.0
        self.musket_loaded = True
        self.reload_timer = 0.0
        self.shoot_flash = 0.0
        self.damage_flash = 0.0

    def update(self, dt, keys):
        dx = 0
        if keys[pygame.K_LEFT] or keys[pygame.K_a]:
            dx -= 1; self.facing = -1
        if keys[pygame.K_RIGHT] or keys[pygame.K_d]:
            dx += 1; self.facing = 1
        speed = PLAYER_SPEED
        if self.carrying:
            speed *= max(0.3, 1.0 - self.carrying.weight * PLAYER_CARRY_SPEED_MUL / 40)
            self.stamina -= STAMINA_WALK_DRAIN * dt * (self.carrying.weight / 15)
        else:
            self.stamina = min(STAMINA_MAX, self.stamina + STAMINA_REGEN * dt)
        if self.stamina <= 0 and self.carrying:
            self.carrying.carried = False
            self.carrying.x = self.x
            self.carrying.y = self.y
            self.carrying = None
            self.stamina = 0
        self.x += dx * speed
        self.x = clamp(self.x, DECK_LEFT + 15, DECK_RIGHT - 15)
        self.y = DECK_Y
        if self.carrying:
            self.carrying.x = self.x + self.facing * 16
            self.carrying.y = self.y - 20
        if dx != 0:
            self.walk_frame += dt * 8
        else:
            self.walk_frame = 0
        if not self.musket_loaded:
            self.reload_timer -= dt
            if self.reload_timer <= 0:
                self.musket_loaded = True
        if self.shoot_flash > 0:
            self.shoot_flash -= dt
        if self.damage_flash > 0:
            self.damage_flash -= dt

    def near_edge(self):
        return self.x < DECK_LEFT + THROW_MARGIN or self.x > DECK_RIGHT - THROW_MARGIN

    def try_pickup(self, chests):
        if self.carrying:
            return None
        pr = pygame.Rect(self.x - 28, self.y - 50, 56, 50)
        for c in chests:
            if not c.carried and pr.colliderect(c.rect()):
                if self.stamina >= c.weight * THROW_STAMINA_MULT:
                    c.carried = True
                    self.carrying = c
                    return c
        return None

    def try_throw(self):
        if not self.carrying:
            return None, False, (0, 0)
        chest = self.carrying
        cost = chest.weight * THROW_STAMINA_MULT
        if self.near_edge() and self.stamina >= cost:
            self.stamina -= cost
            self.carrying = None
            chest.carried = False
            sx = self.x - 40 if self.x < DECK_LEFT + THROW_MARGIN else self.x + 40
            sy = WATERLINE_Y + 10
            return chest, True, (sx, sy)
        else:
            self.carrying = None
            chest.carried = False
            chest.x = self.x
            chest.y = self.y
            return chest, False, (0, 0)

    def try_shoot(self):
        if self.musket_loaded and not self.carrying:
            self.musket_loaded = False
            self.reload_timer = MUSKET_RELOAD_TIME
            self.shoot_flash = 0.15
            return Bullet(self.x + self.facing * 30, self.y - 32, self.facing)
        return None

    def take_hit(self, dmg):
        self.health -= dmg
        self.damage_flash = 0.2
        if self.health < 0:
            self.health = 0

    def draw(self, surf):
        x, y = int(self.x), int(self.y)
        f = self.facing
        bob = int(math.sin(self.walk_frame) * 2)

        coat_c = (100, 100, 255) if self.damage_flash > 0 else COAT_BLUE

        pygame.draw.rect(surf, PANTS_TAN, (x - 7, y - 18 + bob, 6, 16))
        pygame.draw.rect(surf, PANTS_TAN, (x + 1, y - 18 + bob, 6, 16))
        pygame.draw.rect(surf, BLACK, (x - 8, y - 4 + bob, 7, 4))
        pygame.draw.rect(surf, BLACK, (x + 1, y - 4 + bob, 7, 4))
        pygame.draw.rect(surf, coat_c, (x - 9, y - 34 + bob, 18, 18))
        for by2 in range(y - 30 + bob, y - 18 + bob, 5):
            pygame.draw.circle(surf, (220, 200, 60), (x, by2), 1)
        arm_y = y - 30 + bob
        if self.carrying:
            pygame.draw.rect(surf, coat_c, (x + f * 8, arm_y + 2, f * 10, 5))
            pygame.draw.circle(surf, SKIN, (x + f * 18, arm_y + 4), 3)
        else:
            pygame.draw.rect(surf, coat_c, (x - f * 12, arm_y, 5, 12))
            pygame.draw.circle(surf, SKIN, (x - f * 12 + 2, arm_y + 13), 3)
            pygame.draw.rect(surf, coat_c, (x + f * 8, arm_y, 5, 10))
            pygame.draw.circle(surf, SKIN, (x + f * 8 + 2, arm_y + 10), 3)
            musket_y = arm_y + 6
            pygame.draw.line(surf, (100, 70, 40), (x + f * 6, musket_y), (x + f * 34, musket_y), 3)
            pygame.draw.line(surf, (180, 180, 190), (x + f * 34, musket_y), (x + f * 42, musket_y - 2), 2)
            if self.shoot_flash > 0:
                pygame.draw.circle(surf, MUZZLE_FLASH, (x + f * 42, musket_y), 8)
                pygame.draw.circle(surf, WHITE, (x + f * 42, musket_y), 4)
        head_y = y - 42 + bob
        pygame.draw.circle(surf, SKIN, (x, head_y), 8)
        pygame.draw.ellipse(surf, HAIR_GRAY, (x - 10, head_y - 3, 20, 7))
        pygame.draw.ellipse(surf, HAIR_GRAY, (x - 11, head_y - 1, 6, 12))
        pygame.draw.ellipse(surf, HAIR_GRAY, (x + 5, head_y - 1, 6, 12))
        ex = x + f * 3
        pygame.draw.circle(surf, BLACK, (ex - 2, head_y), 2)
        pygame.draw.circle(surf, BLACK, (ex + 3, head_y), 2)
        pygame.draw.circle(surf, BLACK, (ex - 2, head_y), 4, 1)
        pygame.draw.circle(surf, BLACK, (ex + 3, head_y), 4, 1)
        pygame.draw.line(surf, BLACK, (ex - 6, head_y), (ex + 7, head_y), 1)
        hat_y = head_y - 11
        pygame.draw.polygon(surf, (30, 30, 30), [
            (x - 13, hat_y + 5), (x + 13, hat_y + 5),
            (x + 7, hat_y - 2), (x, hat_y - 6), (x - 7, hat_y - 2)])
        pygame.draw.rect(surf, (30, 30, 30), (x - 9, hat_y + 3, 18, 4))
        if self.carrying and self.near_edge():
            iy = y - 65
            pygame.draw.polygon(surf, (100, 255, 100), [(x - 6, iy), (x + 6, iy), (x, iy + 8)])

# ---------------------------------------------------------------------------
# Ship drawing (side view Mayflower)
# ---------------------------------------------------------------------------

def draw_sky(surf):
    draw_gradient_rect(surf, (0, 0, SCREEN_W, WATERLINE_Y), SKY_TOP, SKY_BOT)
    pygame.draw.circle(surf, MOON_COLOR, (860, 80), 30)
    pygame.draw.circle(surf, SKY_TOP, (870, 74), 26)
    random.seed(42)
    for _ in range(80):
        sx, sy = random.randint(0, SCREEN_W), random.randint(0, 300)
        b = random.randint(150, 255)
        pygame.draw.circle(surf, (b, b, b), (sx, sy), random.choice([1, 1, 1, 2]))
    random.seed()


def draw_water(surf, tick):
    draw_gradient_rect(surf, (0, WATERLINE_Y, SCREEN_W, SCREEN_H - WATERLINE_Y), WATER, WATER_DARK)
    for wy in range(WATERLINE_Y + 6, SCREEN_H, 14):
        pts = []
        for wx in range(0, SCREEN_W + 20, 16):
            offset = math.sin(wx * 0.025 + tick * 2.5 + wy * 0.08) * 3
            pts.append((wx, wy + offset))
        if len(pts) > 1:
            pygame.draw.lines(surf, WATER_LIGHT, False, pts, 1)


def draw_ship(surf):
    cy = WATERLINE_Y
    hull_pts = [
        (STERN_X, cy - 90), (STERN_X - 15, cy - 70), (STERN_X - 10, cy - 30),
        (STERN_X + 10, cy + 30), (STERN_X + 60, cy + 55), (SCREEN_W // 2, cy + 65),
        (DECK_RIGHT - 40, cy + 50), (BOW_TIP_X - 20, cy + 10), (BOW_TIP_X + 10, cy - 50),
        (BOW_TIP_X - 10, cy - 70), (DECK_RIGHT, cy - 110), (DECK_LEFT, cy - 110), (STERN_X, cy - 90),
    ]
    shadow = [(px + 5, py + 5) for px, py in hull_pts]
    pygame.draw.polygon(surf, (10, 30, 60), shadow)
    pygame.draw.polygon(surf, HULL_MID, hull_pts)
    for hy in range(cy - 80, cy + 50, 14):
        pygame.draw.line(surf, HULL_DARK, (STERN_X - 5, hy), (BOW_TIP_X, hy), 1)
    pygame.draw.line(surf, HULL_BAND, (STERN_X, cy - 60), (BOW_TIP_X, cy - 60), 4)
    pygame.draw.line(surf, HULL_BAND, (STERN_X + 5, cy - 30), (BOW_TIP_X - 30, cy - 30), 3)
    for gx in range(DECK_LEFT + 60, DECK_RIGHT - 40, 70):
        pygame.draw.rect(surf, BLACK, (gx, cy - 50, 14, 12))
        pygame.draw.rect(surf, HULL_DARK, (gx - 1, cy - 51, 16, 14), 1)
    pygame.draw.polygon(surf, HULL_DARK, hull_pts, 3)
    pygame.draw.rect(surf, WOOD_LIGHT, (DECK_LEFT, DECK_Y, DECK_RIGHT - DECK_LEFT, 8))
    for px in range(DECK_LEFT, DECK_RIGHT, 30):
        pygame.draw.line(surf, WOOD_DARK, (px, DECK_Y), (px, DECK_Y + 8), 1)
    sc_y = UPPER_DECK_Y
    pygame.draw.rect(surf, WOOD_PLANK, (STERN_X, sc_y, UPPER_RIGHT - STERN_X, DECK_Y - sc_y))
    pygame.draw.rect(surf, WOOD_DARK, (STERN_X, sc_y, UPPER_RIGHT - STERN_X, DECK_Y - sc_y), 2)
    for wx in range(STERN_X + 20, UPPER_RIGHT - 10, 40):
        pygame.draw.rect(surf, (40, 35, 25), (wx, sc_y + 15, 20, 25))
        pygame.draw.rect(surf, (180, 160, 80), (wx + 2, sc_y + 17, 16, 21))
        pygame.draw.rect(surf, WOOD_DARK, (wx, sc_y + 15, 20, 25), 1)
    pygame.draw.rect(surf, RAIL_COLOR, (STERN_X, sc_y - 4, UPPER_RIGHT - STERN_X, 4))
    for px in range(STERN_X, UPPER_RIGHT + 1, 25):
        pygame.draw.rect(surf, WOOD_DARK, (px - 2, sc_y - 14, 4, 14))
    fc_left = DECK_RIGHT - 140
    fc_y = DECK_Y - 35
    pygame.draw.rect(surf, WOOD_PLANK, (fc_left, fc_y, DECK_RIGHT - fc_left, DECK_Y - fc_y))
    pygame.draw.rect(surf, WOOD_DARK, (fc_left, fc_y, DECK_RIGHT - fc_left, DECK_Y - fc_y), 2)
    pygame.draw.rect(surf, RAIL_COLOR, (fc_left, fc_y - 4, DECK_RIGHT - fc_left, 4))
    rail_y = DECK_Y - 30
    for px in range(DECK_LEFT, DECK_RIGHT + 1, 35):
        pygame.draw.rect(surf, WOOD_DARK, (px - 2, rail_y, 3, 30))
    pygame.draw.line(surf, RAIL_COLOR, (DECK_LEFT, rail_y), (DECK_RIGHT, rail_y), 3)
    pygame.draw.line(surf, RAIL_COLOR, (DECK_LEFT, rail_y + 15), (DECK_RIGHT, rail_y + 15), 2)
    masts = [
        (STERN_X + 50, DECK_Y, 220, 50, "mizzen"),
        (DECK_CX, DECK_Y, 310, 80, "main"),
        (DECK_RIGHT - 100, DECK_Y, 260, 65, "fore"),
    ]
    for mx, my, height, sail_w, name in masts:
        top_y = my - height
        pygame.draw.line(surf, WOOD_DARK, (mx, my), (mx, top_y), 4)
        if name == "main":
            cn_y = top_y + 30
            pygame.draw.rect(surf, WOOD_DARK, (mx - 12, cn_y, 24, 4))
            pygame.draw.rect(surf, WOOD_DARK, (mx - 10, cn_y - 8, 2, 8))
            pygame.draw.rect(surf, WOOD_DARK, (mx + 8, cn_y - 8, 2, 8))
        yard_positions = [0.2, 0.5]
        if height > 250:
            yard_positions.append(0.75)
        for i, frac in enumerate(yard_positions):
            yy = top_y + int(height * frac)
            w = sail_w - i * 10
            pygame.draw.line(surf, WOOD_DARK, (mx - w, yy), (mx + w, yy), 3)
            sail_h = int(height * 0.22)
            sr = pygame.Rect(mx - w + 3, yy + 2, w * 2 - 6, sail_h)
            pygame.draw.rect(surf, SAIL_COLOR, sr)
            for sy in range(sr.y + 6, sr.bottom, 8):
                pygame.draw.line(surf, SAIL_SHADOW, (sr.x, sy), (sr.right, sy), 1)
            pygame.draw.rect(surf, SAIL_SHADOW, sr, 1)
        pygame.draw.line(surf, ROPE_COLOR, (mx, top_y), (mx - 50, my - 5), 1)
        pygame.draw.line(surf, ROPE_COLOR, (mx, top_y), (mx + 50, my - 5), 1)
    pygame.draw.line(surf, WOOD_DARK, (BOW_TIP_X - 30, DECK_Y - 50), (BOW_TIP_X + 60, DECK_Y - 130), 4)
    pygame.draw.polygon(surf, SAIL_COLOR, [
        (BOW_TIP_X + 55, DECK_Y - 125), (BOW_TIP_X - 10, DECK_Y - 40),
        (DECK_RIGHT - 100, DECK_Y - 310 + 30)])
    pygame.draw.polygon(surf, SAIL_SHADOW, [
        (BOW_TIP_X + 55, DECK_Y - 125), (BOW_TIP_X - 10, DECK_Y - 40),
        (DECK_RIGHT - 100, DECK_Y - 310 + 30)], 1)
    flag_y_top = DECK_Y - 310
    pygame.draw.polygon(surf, FLAG_RED, [
        (DECK_CX + 2, flag_y_top), (DECK_CX + 30, flag_y_top + 8), (DECK_CX + 2, flag_y_top + 16)])

# ---------------------------------------------------------------------------
# HUD
# ---------------------------------------------------------------------------

def draw_hud(surf, player, font, font_sm, time_left, level, redcoats_killed, boss=None):
    hud = pygame.Surface((SCREEN_W, 56), pygame.SRCALPHA)
    hud.fill((0, 0, 0, 190))
    surf.blit(hud, (0, 0))

    surf.blit(font.render(f"Score: {player.score}", True, WHITE), (16, 6))
    surf.blit(font_sm.render(f"Redcoats: {redcoats_killed}", True, (255, 180, 180)), (16, 28))

    level_txt = f"LEVEL {level}" if level <= 9 else "BOSS BATTLE"
    level_c = GOLD if level == 10 else WHITE
    lt = font.render(level_txt, True, level_c)
    surf.blit(lt, (SCREEN_W // 2 - lt.get_width() // 2, 4))

    if level <= 9:
        mins, secs = int(time_left) // 60, int(time_left) % 60
        tt = font_sm.render(f"{mins}:{secs:02d}", True, WHITE)
        surf.blit(tt, (SCREEN_W // 2 - tt.get_width() // 2, 28))
    elif boss and not boss.dying:
        bt = font_sm.render(f"Boss HP: {boss.hp}/{boss.max_hp}", True, (255, 100, 100))
        surf.blit(bt, (SCREEN_W // 2 - bt.get_width() // 2, 28))

    # Health
    hb_x, hb_w, hb_h = SCREEN_W - 430, 180, 16
    pygame.draw.rect(surf, STAMINA_BG, (hb_x, 8, hb_w, hb_h))
    hfill = player.health / HEALTH_MAX
    pygame.draw.rect(surf, HEALTH_FG, (hb_x, 8, int(hb_w * hfill), hb_h))
    pygame.draw.rect(surf, WHITE, (hb_x, 8, hb_w, hb_h), 1)
    surf.blit(font_sm.render("HEALTH", True, WHITE), (hb_x + 65, 9))

    # Stamina
    sb_x, sb_w = SCREEN_W - 220, 200
    pygame.draw.rect(surf, STAMINA_BG, (sb_x, 8, sb_w, hb_h))
    sfill = player.stamina / STAMINA_MAX
    pygame.draw.rect(surf, STAMINA_FG if sfill > 0.3 else STAMINA_LOW, (sb_x, 8, int(sb_w * sfill), hb_h))
    pygame.draw.rect(surf, WHITE, (sb_x, 8, sb_w, hb_h), 1)
    surf.blit(font_sm.render("STAMINA", True, WHITE), (sb_x + 70, 9))

    # Musket
    if player.musket_loaded:
        surf.blit(font_sm.render("[MUSKET READY]", True, (100, 255, 100)), (SCREEN_W - 220, 42))
    else:
        pct = 1.0 - (player.reload_timer / MUSKET_RELOAD_TIME)
        pygame.draw.rect(surf, STAMINA_BG, (SCREEN_W - 220, 30, 80, 10))
        pygame.draw.rect(surf, (255, 200, 100), (SCREEN_W - 220, 30, int(80 * pct), 10))
        pygame.draw.rect(surf, WHITE, (SCREEN_W - 220, 30, 80, 10), 1)
        surf.blit(font_sm.render("Reloading...", True, (255, 200, 100)), (SCREEN_W - 220, 42))

    if player.carrying:
        ct = font_sm.render(f"Carrying: {player.carrying.name} ({player.carrying.weight} lbs)", True, (255, 220, 100))
        surf.blit(ct, (SCREEN_W // 2 - ct.get_width() // 2, 42))

# ---------------------------------------------------------------------------
# Arcade score entry & leaderboard screens
# ---------------------------------------------------------------------------

async def name_entry_screen(screen, clock, fonts, score, level):
    """3-character name + 4-digit PIN entry. Returns (name, pin)."""
    font_lg, font, font_sm = fonts
    name_chars = ["A", "A", "A"]
    pin_chars = ["0", "0", "0", "0"]
    cursor = 0  # 0-2 = name, 3-6 = pin
    total_slots = 7
    VALID_NAME = "ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789"
    VALID_PIN = "0123456789"

    while True:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit(); sys.exit()
            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_ESCAPE:
                    return None, None
                if event.key == pygame.K_RETURN:
                    return "".join(name_chars), "".join(pin_chars)
                if event.key in (pygame.K_RIGHT, pygame.K_TAB):
                    cursor = (cursor + 1) % total_slots
                if event.key == pygame.K_LEFT:
                    cursor = (cursor - 1) % total_slots
                if event.key == pygame.K_UP:
                    if cursor < 3:
                        idx = VALID_NAME.index(name_chars[cursor])
                        name_chars[cursor] = VALID_NAME[(idx + 1) % len(VALID_NAME)]
                    else:
                        idx = VALID_PIN.index(pin_chars[cursor - 3])
                        pin_chars[cursor - 3] = VALID_PIN[(idx + 1) % len(VALID_PIN)]
                if event.key == pygame.K_DOWN:
                    if cursor < 3:
                        idx = VALID_NAME.index(name_chars[cursor])
                        name_chars[cursor] = VALID_NAME[(idx - 1) % len(VALID_NAME)]
                    else:
                        idx = VALID_PIN.index(pin_chars[cursor - 3])
                        pin_chars[cursor - 3] = VALID_PIN[(idx - 1) % len(VALID_PIN)]
                # Direct typing
                if event.unicode:
                    ch = event.unicode.upper()
                    if cursor < 3 and ch in VALID_NAME:
                        name_chars[cursor] = ch
                        if cursor < total_slots - 1:
                            cursor += 1
                    elif cursor >= 3 and ch in VALID_PIN:
                        pin_chars[cursor - 3] = ch
                        if cursor < total_slots - 1:
                            cursor += 1

        screen.fill(ARCADE_BG)

        # Title
        t1 = font_lg.render("NEW HIGH SCORE!", True, GOLD)
        screen.blit(t1, (SCREEN_W // 2 - t1.get_width() // 2, 100))

        t2 = font.render(f"Score: {score}   Level: {level}", True, WHITE)
        screen.blit(t2, (SCREEN_W // 2 - t2.get_width() // 2, 180))

        # Name entry
        t3 = font.render("ENTER YOUR INITIALS", True, (180, 180, 255))
        screen.blit(t3, (SCREEN_W // 2 - t3.get_width() // 2, 250))

        box_w, box_h, gap = 60, 70, 15
        total_w = 3 * box_w + 2 * gap + 40 + 4 * box_w + 3 * gap
        start_x = SCREEN_W // 2 - total_w // 2
        y = 310

        for i in range(3):
            bx = start_x + i * (box_w + gap)
            selected = cursor == i
            border_c = GOLD if selected else ARCADE_BORDER
            pygame.draw.rect(screen, (20, 15, 50), (bx, y, box_w, box_h))
            pygame.draw.rect(screen, border_c, (bx, y, box_w, box_h), 3)
            ch = font_lg.render(name_chars[i], True, GOLD if selected else WHITE)
            screen.blit(ch, (bx + box_w // 2 - ch.get_width() // 2, y + 8))
            if selected:
                # Arrows
                pygame.draw.polygon(screen, GOLD, [(bx + box_w // 2, y - 12),
                    (bx + box_w // 2 - 8, y - 4), (bx + box_w // 2 + 8, y - 4)])
                pygame.draw.polygon(screen, GOLD, [(bx + box_w // 2, y + box_h + 12),
                    (bx + box_w // 2 - 8, y + box_h + 4), (bx + box_w // 2 + 8, y + box_h + 4)])

        # Separator
        sep_x = start_x + 3 * (box_w + gap)
        dash = font_lg.render("-", True, (100, 100, 140))
        screen.blit(dash, (sep_x, y + 8))

        # PIN entry
        pin_start = sep_x + 40
        t4 = font_sm.render("PIN (to track your scores)", True, (140, 140, 180))
        screen.blit(t4, (pin_start, y - 22))

        for i in range(4):
            bx = pin_start + i * (box_w + gap)
            ci = i + 3
            selected = cursor == ci
            border_c = GOLD if selected else ARCADE_BORDER
            pygame.draw.rect(screen, (20, 15, 50), (bx, y, box_w, box_h))
            pygame.draw.rect(screen, border_c, (bx, y, box_w, box_h), 3)
            ch = font_lg.render(pin_chars[i], True, GOLD if selected else WHITE)
            screen.blit(ch, (bx + box_w // 2 - ch.get_width() // 2, y + 8))
            if selected:
                pygame.draw.polygon(screen, GOLD, [(bx + box_w // 2, y - 12),
                    (bx + box_w // 2 - 8, y - 4), (bx + box_w // 2 + 8, y - 4)])
                pygame.draw.polygon(screen, GOLD, [(bx + box_w // 2, y + box_h + 12),
                    (bx + box_w // 2 - 8, y + box_h + 4), (bx + box_w // 2 + 8, y + box_h + 4)])

        # Instructions
        inst = [
            "UP/DOWN or TYPE to change  |  LEFT/RIGHT to move  |  ENTER to confirm  |  ESC to skip"
        ]
        for i, line in enumerate(inst):
            t = font_sm.render(line, True, (140, 140, 160))
            screen.blit(t, (SCREEN_W // 2 - t.get_width() // 2, 500 + i * 20))

        pygame.display.flip()
        clock.tick(30)
        await asyncio.sleep(0)


async def leaderboard_screen(screen, clock, fonts, current_score=None):
    """Show high scores. Press any key to continue."""
    font_lg, font, font_sm = fonts
    scores = load_scores()

    waiting = True
    while waiting:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit(); sys.exit()
            if event.type == pygame.KEYDOWN:
                waiting = False

        screen.fill(ARCADE_BG)

        t = font_lg.render("HIGH SCORES", True, GOLD)
        screen.blit(t, (SCREEN_W // 2 - t.get_width() // 2, 40))

        # Column headers
        hdr_y = 110
        screen.blit(font.render("RANK", True, (160, 160, 200)), (180, hdr_y))
        screen.blit(font.render("NAME", True, (160, 160, 200)), (300, hdr_y))
        screen.blit(font.render("SCORE", True, (160, 160, 200)), (460, hdr_y))
        screen.blit(font.render("LEVEL", True, (160, 160, 200)), (640, hdr_y))
        pygame.draw.line(screen, ARCADE_BORDER, (160, hdr_y + 28), (780, hdr_y + 28), 2)

        for i, entry in enumerate(scores[:10]):
            row_y = 150 + i * 36
            is_current = current_score and entry["score"] == current_score
            color = GOLD if is_current else WHITE
            if i == 0:
                color = (255, 215, 0)
            elif i == 1:
                color = (200, 200, 210)
            elif i == 2:
                color = (205, 127, 50)

            screen.blit(font.render(f"{i + 1}.", True, color), (200, row_y))
            screen.blit(font.render(entry["name"], True, color), (310, row_y))
            screen.blit(font.render(str(entry["score"]), True, color), (470, row_y))
            screen.blit(font.render(str(entry.get("level", "?")), True, color), (660, row_y))

            if is_current:
                pygame.draw.rect(screen, GOLD, (160, row_y - 2, 640, 30), 1)

        if not scores:
            nt = font.render("No scores yet — be the first!", True, (140, 140, 160))
            screen.blit(nt, (SCREEN_W // 2 - nt.get_width() // 2, 250))

        foot = font_sm.render("Press any key to continue", True, (140, 140, 160))
        screen.blit(foot, (SCREEN_W // 2 - foot.get_width() // 2, SCREEN_H - 50))

        pygame.display.flip()
        clock.tick(30)
        await asyncio.sleep(0)

# ---------------------------------------------------------------------------
# Level transition screen
# ---------------------------------------------------------------------------

async def level_transition(screen, clock, fonts, level, player_score):
    font_lg, font, font_sm = fonts
    timer = 2.5

    while timer > 0:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit(); sys.exit()
            if event.type == pygame.KEYDOWN and event.key == pygame.K_ESCAPE:
                return False  # quit

        timer -= clock.tick(60) / 1000.0

        screen.fill(ARCADE_BG)

        if level <= 9:
            t1 = font_lg.render(f"LEVEL {level}", True, GOLD)
        else:
            t1 = font_lg.render("BOSS BATTLE", True, (255, 60, 60))
        screen.blit(t1, (SCREEN_W // 2 - t1.get_width() // 2, SCREEN_H // 2 - 80))

        if level <= 9:
            cfg = LEVEL_CONFIG[level]
            diff = font.render(f"Difficulty: {'*' * level}", True, (200, 150, 50))
            screen.blit(diff, (SCREEN_W // 2 - diff.get_width() // 2, SCREEN_H // 2))
        else:
            desc = font.render("Defeat the Redcoat General!", True, (255, 150, 150))
            screen.blit(desc, (SCREEN_W // 2 - desc.get_width() // 2, SCREEN_H // 2))

        sc = font_sm.render(f"Score: {player_score}", True, WHITE)
        screen.blit(sc, (SCREEN_W // 2 - sc.get_width() // 2, SCREEN_H // 2 + 50))

        pygame.display.flip()
        await asyncio.sleep(0)

    return True

# ---------------------------------------------------------------------------
# Main game loop
# ---------------------------------------------------------------------------

async def run_level(screen, clock, fonts, sky_surf, ship_surf, player, level):
    """Run a single level. Returns (completed, death_cause)."""
    font_lg, font, font_sm = fonts
    cfg = LEVEL_CONFIG[level]
    redcoat_spawn_int, speed_mult, chest_spawn_int, max_rc = cfg

    chests, redcoats, bullets, enemy_bullets, hearts = [], [], [], [], []
    particles, floats = [], []

    time_left = LEVEL_DURATION
    spawn_timer = 1.0
    redcoat_timer = 2.0
    tick = 0.0
    redcoats_killed = 0
    boss = Boss() if level == 10 else None
    boss_slash_hit_cd = 0.0  # prevent multi-hit per slash

    def spawn_chest():
        ctype = random.choice(CHEST_TYPES)
        x = random.randint(DECK_LEFT + 60, DECK_RIGHT - 60)
        chests.append(TeaChest(x, DECK_Y, ctype))

    for _ in range(3):
        spawn_chest()

    running = True
    while running:
        dt = clock.tick(FPS) / 1000.0
        tick += dt

        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit(); sys.exit()
            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_ESCAPE:
                    return False, "QUIT"
                if event.key == pygame.K_e:
                    player.try_pickup(chests)
                if event.key == pygame.K_SPACE:
                    chest, thrown, splash_pos = player.try_throw()
                    if thrown and chest:
                        player.score += chest.points
                        sx, sy = splash_pos
                        for _ in range(SPLASH_PARTICLES):
                            particles.append(Particle(sx, sy, SPLASH_CLR))
                        floats.append(FloatingText(sx, sy - 30, f"+{chest.points}", (255, 255, 100)))
                        if chest.name == "Large":
                            hearts.append(HeartPickup(player.x, DECK_Y - 120))
                        chests.remove(chest)
                if event.key == pygame.K_f:
                    bullet = player.try_shoot()
                    if bullet:
                        bullets.append(bullet)
                        for _ in range(5):
                            particles.append(Particle(bullet.x, bullet.y, SMOKE_COLOR, gravity=50, life=0.4))

        # Timer (levels 1-9)
        if level <= 9:
            time_left -= dt
            if time_left <= 0:
                return True, None  # level complete

        # Player death
        if player.health <= 0:
            return False, "YOU FELL IN BATTLE!"

        keys = pygame.key.get_pressed()
        player.update(dt, keys)

        # Spawn chests
        spawn_timer -= dt
        if spawn_timer <= 0 and len([c for c in chests if not c.carried]) < MAX_CHESTS:
            spawn_chest()
            spawn_timer = chest_spawn_int

        # Spawn redcoats (not on boss level)
        if level <= 9:
            redcoat_timer -= dt
            if redcoat_timer <= 0 and len(redcoats) < max_rc:
                side = random.choice([-1, 1])
                rx = random.randint(DECK_LEFT + 10, DECK_LEFT + 80) if side == -1 else random.randint(DECK_RIGHT - 80, DECK_RIGHT - 10)
                redcoats.append(Redcoat(rx, WATERLINE_Y + 20, speed_mult))
                redcoat_timer = redcoat_spawn_int

        # Update redcoats
        for rc in redcoats:
            rc.update(dt, player.x)
            if rc.on_deck and not rc.dying and abs(rc.x - player.x) < 25:
                player.take_hit(REDCOAT_ATTACK_DMG * dt)
            eb = rc.try_shoot(player.x)
            if eb:
                enemy_bullets.append(eb)
                for _ in range(3):
                    particles.append(Particle(eb.x, eb.y, SMOKE_COLOR, gravity=50, life=0.3))

        # Boss update
        if boss and boss.alive:
            boss.update(dt, player.x)
            # Boss slash damage
            if boss_slash_hit_cd > 0:
                boss_slash_hit_cd -= dt
            if boss.is_slash_hitting(player.x) and boss_slash_hit_cd <= 0:
                player.take_hit(BOSS_SLASH_DMG)
                boss_slash_hit_cd = 0.5
                floats.append(FloatingText(player.x, player.y - 60, f"-{int(BOSS_SLASH_DMG)}", (255, 60, 60)))
                for _ in range(6):
                    particles.append(Particle(player.x, player.y - 20, (255, 100, 100), gravity=200, life=0.4))

            # Boss defeated
            if boss.dying and not boss.alive:
                return True, None
        elif boss and not boss.alive:
            return True, None

        # Player bullets vs redcoats
        for b in bullets:
            b.update(dt)
            if not b.alive:
                continue
            for rc in redcoats:
                if rc.dying:
                    continue
                if rc.hit_rect().collidepoint(b.x, b.y):
                    rc.die(1 if b.vx > 0 else -1)
                    b.alive = False
                    redcoats_killed += 1
                    player.score += 50
                    floats.append(FloatingText(rc.x, rc.y - 55, "+50", (255, 150, 150)))
                    break
            # Player bullets vs boss
            if b.alive and boss and not boss.dying and boss.alive:
                if boss.hit_rect().collidepoint(b.x, b.y):
                    boss.take_hit()
                    b.alive = False
                    player.health = min(HEALTH_MAX, player.health + BOSS_HIT_HEAL)
                    player.score += 100
                    floats.append(FloatingText(boss.x, boss.y - 80, "+HP!", (100, 255, 100)))
                    floats.append(FloatingText(boss.x + 20, boss.y - 60, "+100", (255, 255, 100)))
                    for _ in range(8):
                        particles.append(Particle(b.x, b.y, (255, 200, 50), gravity=150, life=0.5))

        # Enemy bullets vs player
        for eb in enemy_bullets:
            eb.update(dt)
            if eb.alive and eb.hit_player(player):
                player.take_hit(ENEMY_BULLET_DMG)
                eb.alive = False
                floats.append(FloatingText(player.x, player.y - 60, f"-{int(ENEMY_BULLET_DMG)}", (255, 80, 80)))

        # Hearts
        for h in hearts:
            h.update(dt)
            if h.alive and h.landed and h.hit_player(player):
                player.health = min(HEALTH_MAX, player.health + HEART_HEAL_AMOUNT)
                h.alive = False
                floats.append(FloatingText(h.x, h.y - 20, f"+{int(HEART_HEAL_AMOUNT)} HP", (255, 100, 150)))

        bullets = [b for b in bullets if b.alive]
        enemy_bullets = [eb for eb in enemy_bullets if eb.alive]
        hearts = [h for h in hearts if h.alive]
        redcoats = [r for r in redcoats if r.alive]

        particles = [p for p in particles if p.life > 0]
        for p in particles:
            p.update(dt)
        floats = [f for f in floats if f.life > 0]
        for f in floats:
            f.update(dt)

        # ---- Draw ----
        screen.blit(sky_surf, (0, 0))
        draw_water(screen, tick)
        screen.blit(ship_surf, (0, 0))

        for c in chests:
            if not c.carried:
                c.draw(screen, font_sm)
        if player.carrying:
            player.carrying.draw(screen, font_sm)

        for h in hearts:
            h.draw(screen)
        for rc in redcoats:
            rc.draw(screen)
        if boss and boss.alive:
            boss.draw(screen)

        player.draw(screen)

        for b in bullets:
            b.draw(screen)
        for eb in enemy_bullets:
            eb.draw(screen)
        for p in particles:
            p.draw(screen)
        for f in floats:
            f.draw(screen, font)

        draw_hud(screen, player, font, font_sm, time_left, level, redcoats_killed, boss)

        # Instructions bar
        if level == 10:
            inst = font_sm.render(
                "WASD = Move | F = Shoot (heals you!) | SPACE = Throw tea | Dodge the sword!",
                True, (200, 200, 200))
        else:
            inst = font_sm.render(
                "WASD = Move | E = Pick up | SPACE = Throw overboard | F = Shoot | ESC = Quit",
                True, (200, 200, 200))
        screen.blit(inst, (SCREEN_W // 2 - inst.get_width() // 2, SCREEN_H - 22))

        pygame.display.flip()
        await asyncio.sleep(0)

    return False, "QUIT"

# ---------------------------------------------------------------------------
# Title screen
# ---------------------------------------------------------------------------

async def title_screen(screen, clock, fonts):
    font_lg, font, font_sm = fonts
    while True:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit(); sys.exit()
            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_ESCAPE:
                    pygame.quit(); sys.exit()
                if event.key == pygame.K_h:
                    await leaderboard_screen(screen, clock, fonts)
                    continue
                return  # start game

        screen.fill(ARCADE_BG)

        t1 = font_lg.render("BOSTON TEA PARTY", True, GOLD)
        screen.blit(t1, (SCREEN_W // 2 - t1.get_width() // 2, 150))

        lines = [
            "Storm the Mayflower as Benjamin Franklin!",
            "Throw tea overboard. Fight the Redcoats.",
            "Survive 10 levels and defeat the Boss!",
            "",
            "Press any key to start",
            "H = View High Scores    ESC = Quit",
        ]
        for i, line in enumerate(lines):
            c = WHITE if i < 3 else (160, 160, 200) if line else WHITE
            t = font.render(line, True, c) if line else font.render("", True, c)
            screen.blit(t, (SCREEN_W // 2 - t.get_width() // 2, 280 + i * 36))

        # Draw a little ship silhouette
        ship_y = 560
        pygame.draw.polygon(screen, HULL_MID, [
            (350, ship_y), (340, ship_y - 20), (345, ship_y + 15),
            (512, ship_y + 25), (670, ship_y + 10), (690, ship_y - 25),
            (680, ship_y - 40), (660, ship_y - 45), (360, ship_y - 45)])
        pygame.draw.line(screen, WOOD_DARK, (512, ship_y - 45), (512, ship_y - 130), 3)
        pygame.draw.rect(screen, SAIL_COLOR, (485, ship_y - 120, 54, 40))
        pygame.draw.polygon(screen, FLAG_RED, [
            (514, ship_y - 130), (534, ship_y - 124), (514, ship_y - 118)])

        pygame.display.flip()
        clock.tick(30)
        await asyncio.sleep(0)

# ---------------------------------------------------------------------------
# Main
# ---------------------------------------------------------------------------

async def main():
    pygame.init()
    screen = pygame.display.set_mode((SCREEN_W, SCREEN_H))
    pygame.display.set_caption("Boston Tea Party — Storm the Ship!")
    clock = pygame.time.Clock()

    font_lg = pygame.font.Font(None, 52)
    font    = pygame.font.Font(None, 24)
    font_sm = pygame.font.Font(None, 16)
    fonts = (font_lg, font, font_sm)

    sky_surf = pygame.Surface((SCREEN_W, SCREEN_H))
    draw_sky(sky_surf)
    ship_surf = pygame.Surface((SCREEN_W, SCREEN_H), pygame.SRCALPHA)
    draw_ship(ship_surf)

    while True:  # main game loop (restart cycle)
        await title_screen(screen, clock, fonts)

        player = Player(DECK_CX)
        game_won = False
        final_level = 0

        for level in range(1, 11):
            # Reset health between levels (partial heal)
            player.health = min(HEALTH_MAX, player.health + 30)
            player.stamina = STAMINA_MAX
            player.carrying = None
            player.musket_loaded = True
            player.reload_timer = 0

            cont = await level_transition(screen, clock, fonts, level, player.score)
            if not cont:
                break

            completed, death_cause = await run_level(screen, clock, fonts, sky_surf, ship_surf, player, level)
            final_level = level

            if not completed:
                # Death or quit
                if death_cause == "QUIT":
                    break

                # Death screen
                overlay = pygame.Surface((SCREEN_W, SCREEN_H), pygame.SRCALPHA)
                overlay.fill((0, 0, 0, 180))
                screen.blit(overlay, (0, 0))
                dt = font_lg.render(death_cause, True, (255, 80, 80))
                screen.blit(dt, (SCREEN_W // 2 - dt.get_width() // 2, SCREEN_H // 2 - 60))
                sc = font.render(f"Final Score: {player.score}  |  Reached Level {level}", True, WHITE)
                screen.blit(sc, (SCREEN_W // 2 - sc.get_width() // 2, SCREEN_H // 2 + 10))
                pygame.display.flip()
                await asyncio.sleep(2000 / 1000)
                break

            # Level complete bonus
            player.score += level * 200
            if level == 10:
                game_won = True

        # Game over / victory — high score entry
        if game_won:
            screen.fill(ARCADE_BG)
            t = font_lg.render("VICTORY!", True, GOLD)
            screen.blit(t, (SCREEN_W // 2 - t.get_width() // 2, SCREEN_H // 2 - 80))
            t2 = font.render("The tea is in the harbor! Liberty prevails!", True, WHITE)
            screen.blit(t2, (SCREEN_W // 2 - t2.get_width() // 2, SCREEN_H // 2))
            player.score += 5000  # victory bonus
            t3 = font.render(f"Final Score: {player.score} (includes 5000 victory bonus)", True, GOLD)
            screen.blit(t3, (SCREEN_W // 2 - t3.get_width() // 2, SCREEN_H // 2 + 50))
            pygame.display.flip()
            await asyncio.sleep(3000 / 1000)

        if player.score > 0:
            name, pin = await name_entry_screen(screen, clock, fonts, player.score, final_level)
            if name and pin:
                add_score(name, pin, player.score, final_level)
            await leaderboard_screen(screen, clock, fonts, player.score)
        await asyncio.sleep(0)


asyncio.run(main())
